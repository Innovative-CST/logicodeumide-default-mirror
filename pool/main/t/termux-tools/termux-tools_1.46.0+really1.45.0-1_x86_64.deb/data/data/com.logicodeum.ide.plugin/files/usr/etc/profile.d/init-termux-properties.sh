if [ ! -f /data/data/com.logicodeum.ide.plugin/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.logicodeum.ide.plugin/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/com.logicodeum.ide.plugin/files/home/.termux
	cp /data/data/com.logicodeum.ide.plugin/files/usr/share/examples/termux/termux.properties /data/data/com.logicodeum.ide.plugin/files/home/.termux/
fi
