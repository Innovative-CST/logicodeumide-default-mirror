##
## This script is sourced by /data/data/com.logicodeum.ide.plugin/files/usr/bin/login before executing shell.
##
