WEIGHT=10
MAIN="https://innovative-cst.github.io/logicodeumide-default-mirror"
OPEN_JDK="https://innovative-cst.github.io/logicodeumide-openjdk-mirror"
