#!/data/data/com.logicodeum.ide.plugin/files/usr/bin/sh

echo "$@"
